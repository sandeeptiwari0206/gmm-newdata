# GMM Recommendation System — Custom Dataset Deployment Guide

## What Changed in Your Code

Your custom datasets have different column names. Here's the mapping:

| Original Code Expected | Your Dataset Has |
|---|---|
| `user_id` | `customer_id` |
| `category` | `l2_category` |
| `price` (products) | `unit_price` |
| `rating` | ❌ Not present — **derived from invoice data** |
| `popularity` | ❌ Not present — **derived as purchase count per product** |
| `discount_pct` | ❌ Not present — **set to 0** |
| `user.segment` | `customer_type` |
| `user.preferred_category` | `end_use` |
| `invoice.price` | `unit_price` |
| `invoice.purchase_date` | `invoice_date` |

**Files updated:** `sm_preprocessing.py`, `sm_generate_recommendations.py`, `config/config.yaml`

---

## Pre-requisites

Before starting, make sure you have:
- AWS account with SageMaker access
- IAM Role ARN for SageMaker (already in config: `arn:aws:iam::703800905532:role/...`)
- S3 Bucket: `gmm-recommendation-bucket` in `ap-south-1` region
- Python 3.8+ with `pip install sagemaker boto3` on your local machine or SageMaker Studio

---

## Step-by-Step Deployment

### STEP 1 — Set Up Your Environment

Open a terminal in **SageMaker Studio** or your local machine with AWS credentials configured.

```bash
# Install dependencies
pip install sagemaker boto3 scikit-learn pandas numpy joblib PyYAML

# Clone/unzip your project
unzip GMM-custom-dataset-project.zip
cd GMM-custom
```

---

### STEP 2 — Verify Your AWS Credentials

```bash
aws sts get-caller-identity
# Should print your Account ID and ARN
```

Also confirm your S3 bucket exists:
```bash
aws s3 ls s3://gmm-recommendation-bucket --region ap-south-1
# If bucket doesn't exist, create it:
aws s3 mb s3://gmm-recommendation-bucket --region ap-south-1
```

---

### STEP 3 — Upload Your Data to S3

Your 3 custom CSV files are already in `data/raw/`. Upload them to S3:

```bash
python scripts/create_pipeline.py --upload-data
```

This uploads:
- `data/raw/products_raw.csv` → `s3://gmm-recommendation-bucket/gmm-recommendation/data/products_raw.csv`
- `data/raw/users.csv` → `s3://gmm-recommendation-bucket/gmm-recommendation/data/users.csv`
- `data/raw/invoices.csv` → `s3://gmm-recommendation-bucket/gmm-recommendation/data/invoices.csv`

You can verify the upload:
```bash
aws s3 ls s3://gmm-recommendation-bucket/gmm-recommendation/data/ --region ap-south-1
```

---

### STEP 4 — Create and Deploy the SageMaker Pipeline

```bash
python scripts/create_pipeline.py --upsert
```

This will:
1. Build the pipeline definition (5 steps)
2. Create/update it in SageMaker

You should see output like:
```
Pipeline upserted → gmm-recommendation-pipeline
Pipeline steps: ['GMMPreprocessing', 'GMMTraining', 'GMMEvaluation', 'GMMBICCondition', 'GMMGenerateRecommendations']
```

---

### STEP 5 — Run the Pipeline

```bash
python scripts/create_pipeline.py --upsert --start
```

Or to start with a custom BIC threshold:
```bash
python scripts/create_pipeline.py --upsert --start --baseline-bic 500000
```

---

### STEP 6 — Monitor Pipeline Execution

**Option A — AWS Console:**
1. Go to AWS Console → SageMaker → Pipelines
2. Click on `gmm-recommendation-pipeline`
3. Click the latest execution to see step-by-step progress

**Option B — Command line:**
```bash
python scripts/check_pipeline_logs.py
```

**Pipeline steps and estimated time:**

| Step | What it does | Est. Time |
|---|---|---|
| GMMPreprocessing | Loads CSVs, derives features, saves preprocessor | 5–10 min |
| GMMTraining | Grid search GMM (3–7 components × 4 cov types) | 15–30 min |
| GMMEvaluation | Computes BIC, silhouette, cluster stats | 5–10 min |
| GMMBICCondition | Checks if model is good enough | < 1 min |
| GMMGenerateRecommendations | Generates recs for all 5000 customers | 10–20 min |

---

### STEP 7 — Get Your Output

After pipeline completes, your recommendations CSV will be in S3:

```bash
aws s3 cp s3://gmm-recommendation-bucket/gmm-recommendation/recommendations/all_customer_recommendations.csv ./output/ --region ap-south-1
```

The CSV contains these columns for every customer:

| Column | Description |
|---|---|
| `customer_id` | Your customer ID (e.g., C00001) |
| `rank` | Recommendation rank (1 = best) |
| `product_id` | Recommended product |
| `product_name` | Product name |
| `category` | l2_category from your data |
| `brand` | Product brand |
| `price` | Unit price |
| `popularity` | How many times purchased across all customers |
| `total_revenue` | Total historical revenue for this product |
| `final_score` | Recommendation score (0–1) |
| `cluster_id` | Which GMM cluster the product belongs to |
| `preferred_cluster` | Customer's preferred cluster based on purchase history |
| `strategy` | Strategy used (balanced/popular/value/diverse) |
| `reasons` | Human-readable reason string |

---

### STEP 8 — (Optional) Register and Deploy Real-Time Endpoint

If the BIC condition was met, the model is auto-registered in Model Registry with `PendingManualApproval`.

To approve and deploy a real-time endpoint:

```bash
# 1. Approve the model in console:
# SageMaker → Model Registry → GMM-Recommendation-Models → Approve

# 2. Deploy endpoint
python -c "
import sagemaker, boto3
from sagemaker import ModelPackage

sm = boto3.client('sagemaker', region_name='ap-south-1')

# Get latest approved model package ARN from registry
response = sm.list_model_packages(
    ModelPackageGroupName='GMM-Recommendation-Models',
    ModelApprovalStatus='Approved',
    SortBy='CreationTime',
    SortOrder='Descending',
)
arn = response['ModelPackageSummaryList'][0]['ModelPackageArn']
print('Deploying:', arn)

model = ModelPackage(
    role='arn:aws:iam::703800905532:role/service-role/AmazonSageMaker-ExecutionRole-20260219T112938',
    model_package_arn=arn,
    sagemaker_session=sagemaker.Session(),
)
predictor = model.deploy(
    initial_instance_count=1,
    instance_type='ml.m5.xlarge',
    endpoint_name='gmm-recommendation-endpoint',
)
print('Endpoint deployed!')
"
```

**Test the endpoint:**
```bash
python -c "
import boto3, json
client = boto3.client('sagemaker-runtime', region_name='ap-south-1')
response = client.invoke_endpoint(
    EndpointName='gmm-recommendation-endpoint',
    ContentType='application/json',
    Body=json.dumps({'user_id': 'C00001', 'top_n': 5, 'strategy': 'balanced'}),
)
print(json.loads(response['Body'].read()))
"
```

---

## Re-running With New Data

If you get new data in the future, just:
1. Replace files in `data/raw/`
2. Upload to S3: `python scripts/create_pipeline.py --upload-data`
3. Start pipeline: `python scripts/create_pipeline.py --start`

---

## Troubleshooting

| Error | Fix |
|---|---|
| `botocore.exceptions.NoCredentialsError` | Run `aws configure` or set credentials |
| `AccessDenied` on S3 | Check your IAM role has S3 read/write permissions |
| Step fails in console | Click the step → View logs → CloudWatch |
| `model.tar.gz not found` | Training step failed — check training logs |
| BIC condition failed (model not registered) | Run with `--baseline-bic 0` to force registration |
